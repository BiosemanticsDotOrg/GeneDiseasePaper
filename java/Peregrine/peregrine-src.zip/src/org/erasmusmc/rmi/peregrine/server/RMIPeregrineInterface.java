package org.erasmusmc.rmi.peregrine.server;

import java.rmi.Remote;
import java.rmi.RemoteException;

import org.erasmusmc.rmi.peregrine.client.RMIPeregrineResult;

public interface RMIPeregrineInterface extends Remote {
  public static final int NO_DISAMBIGUATION = 0;
  public static final int DISAMBIGUATION = 1;
  public static final int DISAMBIGUATION_WITH_DETAILS = 2;
  public RMIPeregrineResult index(String string, int disambiguation) throws RemoteException;
}
