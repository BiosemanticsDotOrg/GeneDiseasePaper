package org.erasmusmc.rmi.peregrine.client;

import java.rmi.Naming;
import java.rmi.RemoteException;

import org.erasmusmc.rmi.peregrine.server.RMIPeregrineInterface;

public class RMIPeregrineConnector {
  private RMIPeregrineInterface rmiPeregrineInterface;
  
  public RMIPeregrineConnector (String server, int port, String serviceName) throws Exception {
  	rmiPeregrineInterface = (RMIPeregrineInterface) Naming.lookup("rmi://" + server + ":" + port + "/" + serviceName);
  }
  
  public RMIPeregrineResult index(String string, int disambiguation) {
    RMIPeregrineResult result = null;
    try {
      result = rmiPeregrineInterface.index(string, disambiguation);
    } catch (RemoteException e) {
      e.printStackTrace();
    }
    return result;
  }
}
