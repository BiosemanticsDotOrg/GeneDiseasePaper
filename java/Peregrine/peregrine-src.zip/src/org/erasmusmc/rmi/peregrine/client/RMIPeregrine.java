package org.erasmusmc.rmi.peregrine.client;

import org.erasmusmc.peregrine.AbstractPeregrine;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails;
import org.erasmusmc.rmi.peregrine.server.RMIPeregrineInterface;

/**
 * RMI interface to a Peregrine running on a server
 * @author Schuemie
 *
 */
public class RMIPeregrine extends AbstractPeregrine {
  private RMIPeregrineConnector connector;
  private boolean disambiguate = true;
  private boolean getDetails = false;
  
  /**
   * Data object containing the disambiguation details of the last indexation (if DisambiguationDetails is set to true).
   */
  public DisambiguationDetails disambiguationDetails;

  /**
   * Connect to the Peregrine server running on the server
   * @param server  The name or IP address of the server
   * @param port    The port on which the server can be contacted
   * @param serviceName The name of the service
   */
  public RMIPeregrine(String server, int port, String serviceName) throws Exception {
    connector = new RMIPeregrineConnector(server, port, serviceName);
  }

  
  @Override
  public void index(String string) {
    int disambiguation;
    if (disambiguate)
      if (getDetails)
        disambiguation = RMIPeregrineInterface.DISAMBIGUATION_WITH_DETAILS;
      else
        disambiguation = RMIPeregrineInterface.DISAMBIGUATION;
    else
      disambiguation = RMIPeregrineInterface.NO_DISAMBIGUATION;
    
    RMIPeregrineResult result = connector.index(string, disambiguation);
    resultConcepts = result.resultConcepts;
    resultTerms = result.resultTerms;
    tokenizer = result.tokenizer;
    disambiguationDetails = result.disambiguationDetails;
  }
  
  /**
   * Specify whether the indexations should make use of the disambigation. The default value is true.
   * @param disambiguate    Set to true to automatically apply disambiguation after indexation.
   */
  public void setDisambiguate(boolean disambiguate) {
    this.disambiguate = disambiguate;
  }
  
  /**
   * Specifiy whether the indexations should return the details of the disambiguation. The default value
   * is false.
   * @param getDetails
   */
  public void setDisambiguationDetails(boolean getDetails){
    this.getDetails = getDetails;
  }
  
  public void release() {
    
  }

}
