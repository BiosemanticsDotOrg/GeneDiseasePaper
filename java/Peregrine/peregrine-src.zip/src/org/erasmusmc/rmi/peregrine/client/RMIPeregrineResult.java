package org.erasmusmc.rmi.peregrine.client;

import java.io.Serializable;
import java.util.List;

import org.erasmusmc.peregrine.ResultConcept;
import org.erasmusmc.peregrine.ResultTerm;
import org.erasmusmc.peregrine.Tokenizer;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails;

public class RMIPeregrineResult implements Serializable {
  private static final long serialVersionUID = 4117222650666669316L;
  public List<ResultConcept> resultConcepts;
  public List<ResultTerm> resultTerms;
  public Tokenizer tokenizer;
  public DisambiguationDetails disambiguationDetails;
}
