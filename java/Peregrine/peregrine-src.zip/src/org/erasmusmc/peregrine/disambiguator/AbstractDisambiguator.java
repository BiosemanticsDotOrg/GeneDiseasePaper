package org.erasmusmc.peregrine.disambiguator;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.erasmusmc.peregrine.ConceptPeregrine;
import org.erasmusmc.peregrine.ResultConcept;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult;

public abstract class AbstractDisambiguator {
  private Set<ResultConcept> dubiousConcepts = new HashSet<ResultConcept>();
  protected TooManyConceptsRule tooManyConceptsRule;
  
  /**
   * Remove highly ambiguous concepts from the resultConcept list of the
   * specified Peregrine. Apply this method after indexation.
   * 
   * @param peregrine
   *          Specifies the ConceptPeregrine of which the resultConcepts should
   *          be disambiguated
   */
  public void disambiguate(ConceptPeregrine peregrine) {
    disambiguate(peregrine, null);
  }
  
  /**
   * Remove highly ambiguous concepts from the resultConcept list of the
   * specified Peregrine. Apply this method after indexation.
   * 
   * @param peregrine   
   *          Specifies the ConceptPeregrine of which the resultConcepts should
   *          be disambiguated
   * 
   * @return  
   *          Returns details about the disambiguation  
   */
  public DisambiguationDetails disambiguateWithDetails(ConceptPeregrine peregrine) {
    DisambiguationDetails details = new DisambiguationDetails();
    disambiguate(peregrine, details);
    return details;
  }
  
  private void disambiguate(ConceptPeregrine peregrine, DisambiguationDetails details){
    dubiousConcepts.clear();
    Iterator<ResultConcept> conceptIterator = peregrine.resultConcepts.iterator();
    while (conceptIterator.hasNext()) {
      ResultConcept concept = conceptIterator.next();
      List<EvaluationResult> evaluationResults = null;
      if (details != null)
        evaluationResults = new ArrayList<EvaluationResult>();
      
      if (removeConcept(peregrine, concept, evaluationResults)){
        if (details != null)
          details.removedConcepts.add(concept);
        conceptIterator.remove();
      }
      
      if (details != null && evaluationResults.size() != 0)
        details.conceptID2EvaluationResult.put(concept.conceptId, evaluationResults);
    }
    if (!dubiousConcepts.isEmpty())
      tooManyConceptsRule.evaluate(peregrine, details, dubiousConcepts);
  }

  protected void reportDubious(ResultConcept concept){
    dubiousConcepts.add(concept);
  }
  
  protected abstract boolean removeConcept(ConceptPeregrine peregrine, ResultConcept concept, List<EvaluationResult> evaluationResults);
}
