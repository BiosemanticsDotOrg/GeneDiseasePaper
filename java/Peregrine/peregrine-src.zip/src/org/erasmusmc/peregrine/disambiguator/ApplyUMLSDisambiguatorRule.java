package org.erasmusmc.peregrine.disambiguator;

import java.util.List;

import org.erasmusmc.peregrine.ResultConcept;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult;

public class ApplyUMLSDisambiguatorRule {
  public static final int ruleID = 6;
  private int minConceptID;
  private int maxConceptID;

  public ApplyUMLSDisambiguatorRule(int minConceptID, int maxConceptID) {
    this.minConceptID = minConceptID;
    this.maxConceptID = maxConceptID;
  }
  public boolean evaluate(ResultConcept resultConcept, List<EvaluationResult> evaluationResults) {
    if (resultConcept.conceptId >= minConceptID && resultConcept.conceptId < maxConceptID){
      if (evaluationResults != null)
        evaluationResults.add(new EvaluationResult(ruleID, true));
      return true;
    } else
      return false;
  }
}