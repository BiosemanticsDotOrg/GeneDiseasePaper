package org.erasmusmc.peregrine.disambiguator;

import java.util.ArrayList;
import java.util.List;

import org.erasmusmc.peregrine.ResultConcept;
import org.erasmusmc.peregrine.ResultTerm;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult.ExtraData;

public class OtherDisambiguatorRule {
  public static final int ruleID = 7;
  private int minConceptID;
  private int maxConceptID;

  public OtherDisambiguatorRule(int minConceptID, int maxConceptID) {
    this.minConceptID = minConceptID;
    this.maxConceptID = maxConceptID;
  }
  
  public boolean evaluate(ResultTerm term, ResultConcept concept, List<EvaluationResult> evaluationResults) {
    for (int conceptID : term.term.conceptId)
      if (conceptID != concept.conceptId && (conceptID < minConceptID || conceptID > maxConceptID)) {
        if (evaluationResults != null) {
          List<ExtraData> extraDatas = new ArrayList<ExtraData>();
          extraDatas.add(new ExtraData(ExtraData.OTHER_CONCEPT, Integer.toString(conceptID)));
          evaluationResults.add(new EvaluationResult(ruleID, true, extraDatas));
        }
        return true;
      } 
    
    if (evaluationResults != null) 
      evaluationResults.add(new EvaluationResult(ruleID, false));
    return false;
  }
}
