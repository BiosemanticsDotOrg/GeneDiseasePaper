package org.erasmusmc.peregrine.disambiguator;

import java.util.ArrayList;
import java.util.List;

import org.erasmusmc.peregrine.ResultConcept;
import org.erasmusmc.peregrine.ResultTerm;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult.ExtraData;

public class IsHomonymRule {
  public static final int ruleID = 1;
  public boolean evaluate(ResultTerm term, ResultConcept concept, List<EvaluationResult> evaluationResults) {
    if (term.term.conceptId.length != 1){
      if (evaluationResults != null){
        List<ExtraData> extraDatas = new ArrayList<ExtraData>();
        for (int conceptID : term.term.conceptId)
          if (conceptID != concept.conceptId) 
            extraDatas.add(new ExtraData(ExtraData.OTHER_CONCEPT, Integer.toString(conceptID)));
        evaluationResults.add(new EvaluationResult(ruleID, true, extraDatas));
      }
      return true;
    } else {
      if (evaluationResults != null)
        evaluationResults.add(new EvaluationResult(ruleID, false));
      return false;
    }
  }
}
