package org.erasmusmc.peregrine.disambiguator;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.erasmusmc.peregrine.ReleasedTerm;
import org.erasmusmc.peregrine.ResultConcept;
import org.erasmusmc.peregrine.ResultTerm;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult;

public class HasSynonymRule {
  public static final int ruleID = 2;
  
  public boolean evaluate(ResultConcept concept, List<EvaluationResult> evaluationResults) {
    boolean result = hasSynonyms(concept); 
    if (evaluationResults != null)
      evaluationResults.add(new EvaluationResult(ruleID, result));
    return result;
  }
  
  private boolean hasSynonyms(ResultConcept concept){
    Set<ReleasedTerm> uniqueTerms = new HashSet<ReleasedTerm>();
    for (ResultTerm term: concept.terms) {
      if (uniqueTerms.add(term.term) && uniqueTerms.size() != 1) {
        return true;
      }
    }
    return false;
  }

}
