package org.erasmusmc.peregrine.disambiguator;

import java.util.List;

import org.erasmusmc.peregrine.ComplexTerms;
import org.erasmusmc.peregrine.ConceptPeregrine;
import org.erasmusmc.peregrine.ResultTerm;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult;

public class IsComplexRule {
  public static final int ruleID = 5;
  private ComplexTerms complexTerms;
  
  public IsComplexRule(ConceptPeregrine peregrine, int minConceptID, int maxConceptID){
    this.complexTerms =  new ComplexTerms(peregrine, minConceptID, maxConceptID);
  }
  
  public boolean evaluate(ResultTerm term, List<EvaluationResult> evaluationResults) {
    boolean result = complexTerms.isComplex(term.term); 
    if (evaluationResults != null)
      evaluationResults.add(new EvaluationResult(ruleID, result));
    return result;
  }

}
