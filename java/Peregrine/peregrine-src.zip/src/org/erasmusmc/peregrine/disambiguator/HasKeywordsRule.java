package org.erasmusmc.peregrine.disambiguator;

import java.util.ArrayList;
import java.util.List;

import org.erasmusmc.peregrine.ConceptKeywords;
import org.erasmusmc.peregrine.ConceptPeregrine;
import org.erasmusmc.peregrine.ResultConcept;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult.ExtraData;

public class HasKeywordsRule {
  public static final int ruleID = 3;
  private ConceptKeywords conceptKeywords;
  
  public HasKeywordsRule(ConceptPeregrine peregrine, int minConceptID, int maxConceptID){
    this.conceptKeywords = new ConceptKeywords(peregrine, minConceptID, maxConceptID);
  }
  
  public boolean evaluate(ResultConcept concept, List<EvaluationResult> evaluationResults) {
    if (evaluationResults != null){
      String keyword = conceptKeywords.findKeyword(concept);
      if (keyword == null){
        evaluationResults.add(new EvaluationResult(ruleID, false));
        return false;
      } else {
        List<ExtraData> extraDatas = new ArrayList<ExtraData>();
        extraDatas.add(new ExtraData(ExtraData.KEYWORD, keyword));
        evaluationResults.add(new EvaluationResult(ruleID, true, extraDatas));
        return true;
      }
    } else {
      return conceptKeywords.hasKeyword(concept);
    }

  }
}

