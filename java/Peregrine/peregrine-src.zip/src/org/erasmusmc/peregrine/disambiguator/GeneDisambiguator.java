package org.erasmusmc.peregrine.disambiguator;

import java.util.List;

import org.erasmusmc.peregrine.ConceptPeregrine;
import org.erasmusmc.peregrine.ResultConcept;
import org.erasmusmc.peregrine.ResultTerm;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult;

/** Removes highly ambiguous results from a ConceptPeregrine indexation */
public class GeneDisambiguator extends AbstractDisambiguator {
  private ApplyGeneDisambiguatorRule applyGeneDisambiguatorRule;
  private IsHomonymRule isHomonymRule;
  private IsPreferredTermRule isPreferredTermRule;
  private IsComplexRule isComplexRule;
  private HasSynonymRule hasSynonymRule;
  private HasKeywordsRule hasKeywordsRule;
  
  /**
   * The gene disambiguator should be initialised using a released ontology before
   * disambiguation.
   * 
   * @param peregrine
   *            Specifies the ConceptPeregrine that should be used for
   *            initalisation.
   * @param minConceptID
   *            The lower end of the range of conceptIDs to which the disambiguator applies.
   * @param maxConceptID
   *            The upper end (exclusive) of the range of conceptIDs.
   */
  public GeneDisambiguator(ConceptPeregrine peregrine, int minConceptID, int maxConceptID){
    applyGeneDisambiguatorRule = new ApplyGeneDisambiguatorRule(minConceptID, maxConceptID);
    isHomonymRule = new IsHomonymRule();
    isPreferredTermRule = new IsPreferredTermRule();
    isComplexRule = new IsComplexRule(peregrine, minConceptID, maxConceptID);
    hasSynonymRule = new HasSynonymRule();
    hasKeywordsRule = new HasKeywordsRule(peregrine, minConceptID, maxConceptID);
  }

  protected boolean removeConcept(ConceptPeregrine peregrine, ResultConcept concept, List<EvaluationResult> evaluationResults){
    if (applyGeneDisambiguatorRule.evaluate(concept, evaluationResults)){
      ResultTerm term = concept.terms.get(0);
      if (!isHomonymRule.evaluate(term, concept, evaluationResults) || 
          isPreferredTermRule.evaluate(term, concept, evaluationResults)) 
        if (isComplexRule.evaluate(term, evaluationResults))
          return false;

      if (hasSynonymRule.evaluate(concept, evaluationResults))
        return false;

      if (hasKeywordsRule.evaluate(concept, evaluationResults))
        return false;

      return true;  
    }
    return false;
  }
}
