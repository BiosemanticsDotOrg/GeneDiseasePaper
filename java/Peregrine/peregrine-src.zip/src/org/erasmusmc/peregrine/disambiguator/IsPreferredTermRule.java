package org.erasmusmc.peregrine.disambiguator;

import java.util.ArrayList;
import java.util.List;

import org.erasmusmc.peregrine.ResultConcept;
import org.erasmusmc.peregrine.ResultTerm;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult;
import org.erasmusmc.peregrine.disambiguator.DisambiguationDetails.EvaluationResult.ExtraData;

public class IsPreferredTermRule {
  public static final int ruleID = 4;
  
  public boolean evaluate(ResultTerm term, ResultConcept concept, List<EvaluationResult> evaluationResults) {
    int termID = -1;
    for (int i = 0; i < term.term.conceptId.length; i++)
      if (term.term.conceptId[i] == concept.conceptId) {
        termID = term.term.termId[i];
        break;
      }
    boolean result = (termID == 0);
    if (evaluationResults != null) {
      List<ExtraData> extraDatas = new ArrayList<ExtraData>();
      extraDatas.add(new ExtraData(ExtraData.TERM_ID, Integer.toString(termID)));
      evaluationResults.add(new EvaluationResult(ruleID, result, extraDatas));
    }
    return result;
  }

}
