package org.erasmusmc.peregrine;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/** Data structure for storing the concepts found in a text after indexation.*/
public class ResultConcept implements Serializable{
  /** The conceptID of a concept found in the text */
  public int conceptId = -1;
  
  /** The ResultTerms associated with this concept. 
   * Each occurrence of the concept in the text is a single ResultTerm. 
   * Retrieving the count of this list therefore gives you the concept-frequency. */
  public List<ResultTerm> terms = new ArrayList<ResultTerm>();
  
  private static final long serialVersionUID = -7952183865655145010L;  
  
  private void readObject(
      ObjectInputStream aInputStream
  ) throws ClassNotFoundException, IOException {
    aInputStream.defaultReadObject();
  }
  
  
  private void writeObject(
      ObjectOutputStream aOutputStream
  ) throws IOException {
    aOutputStream.defaultWriteObject();
  }  
}
