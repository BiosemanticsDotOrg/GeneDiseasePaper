package org.erasmusmc.peregrine;

import org.erasmusmc.peregrine.ConceptPeregrine.TermLink;

/**
 * Internal class for Peregrine
 * @author martijn
 *
 */
public class IndexTerm {
  public int[] checkedWordPos;
  public byte checkedCount = 0;
  public int lastChecked = 0;
  
  public final void insert(int w){
    checkedWordPos[0] = w;
  }
  
  public final void insertFirst(TermLink termlink, int w1, int w2){
    checkedWordPos[termlink.wordPos1] = w1;
    checkedWordPos[termlink.wordPos2] = w2;
    checkedCount = 2;
    lastChecked = w2;
  }
  
  public final void insert(TermLink termlink, int w1, int w2){
    checkedWordPos[termlink.wordPos1] = w1;
    checkedWordPos[termlink.wordPos2] = w2;
    checkedCount++;
    lastChecked = w2;
  }
  
  public final void clear(){
    checkedCount = 0;
    lastChecked = 0;
    for (int i = 0; i < checkedWordPos.length; i++){
      checkedWordPos[i] = -1;
    }
  }
  
  
}
