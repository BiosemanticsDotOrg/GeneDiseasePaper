package org.erasmusmc.peregrine;

import java.io.Serializable;

/** Data structure created by Peregrine after release. */
public class ReleasedTerm implements Serializable{
  
  /** The concept ids of the concepts that are associated with this term */
  public int[] conceptId;
  
  /** For each of the concepts in the conceptID list, this list contains the term ID. 
   * The first term in the ontology for a concept has termID 0, the second has termID 1, etc. */
  public int[] termId;
  
  protected byte length = 0;
  protected boolean ordered = true;
  

  //modified field keeps track of when Term was last modified (this indexation, or a previous one?)
  protected int modified = 0;
  
  public void addConceptAndTermID(int cid, int tid){
    if (conceptId == null){
      conceptId = new int[1];
      conceptId[0] = cid;
    } else {
      int[] temp = new int[conceptId.length+1];
      for (int i = 0; i < conceptId.length; i++)
        temp[i] = conceptId[i];
      temp[conceptId.length] = cid;
      conceptId = temp;
    }
    
    if (termId == null){
      termId = new int[1];
      termId[0] = tid;
    } else {
      int[] temp = new int[termId.length+1];
      for (int i = 0; i < termId.length; i++)
        temp[i] = termId[i];
      temp[termId.length] = tid;
      termId = temp;
    }
  }

  
  private static final long serialVersionUID = -4285808916406972402L;
  
  public static class ReleasedTermIndexed extends ReleasedTerm {
    private static final long serialVersionUID = 5746230295685285437L;
    public int index = -1;
  }

}
